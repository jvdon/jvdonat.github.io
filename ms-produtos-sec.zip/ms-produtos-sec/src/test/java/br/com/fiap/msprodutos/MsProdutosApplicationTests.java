package br.com.fiap.msprodutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
