package br.com.fiap.msprodutos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * <h3 style="color: red">PASSWORD: c0faeeff-d87a-40dc-ab29-5eb33eefc6fa</h3>
 */

@SpringBootApplication
public class MsProdutosApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsProdutosApplication.class, args);
    }
}
