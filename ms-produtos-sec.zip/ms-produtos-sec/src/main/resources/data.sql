INSERT INTO tb_user(email, password) VALUES ('jvd@example.com', '$2a$10$aIm3A0mB0gRP9G7v6TRMt.QAwK2qJNQAVysnITLfcZZ3rqip4VMTy');
INSERT INTO tb_user(email, password) VALUES ('admin@admin.com', '$2a$10$mvYPD1/LbyrdO5NDVLoTZu.npALLEILmmx2cTlFBqgktO7cR2xleq');


INSERT INTO  tb_categoria (nome) VALUES('Eletrônicos');
INSERT INTO  tb_categoria (nome) VALUES('Livros');
INSERT INTO  tb_categoria (nome) VALUES('Informática');

INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Mouse', 'Mouse sem fio da Microsoft', 95.85, 'Mouse preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Teclado', 'Teclado sem fio da Microsoft', 195.85, 'Teclado preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Caixa de som JBL', 'Caixa de som JBL', 355.85, 'Caixa de som bluetoof', 1);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Game of Thrones', 'Livro original da série', 200, 'Volume 1', 2);

INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Mouse', 'Mouse sem fio da Microsoft', 95.85, 'Mouse preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Teclado', 'Teclado sem fio da Microsoft', 195.85, 'Teclado preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Caixa de som JBL', 'Caixa de som JBL', 355.85, 'Caixa de som bluetoof', 1);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Game of Thrones', 'Livro original da série', 200, 'Volume 1', 2);

INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Mouse', 'Mouse sem fio da Microsoft', 95.85, 'Mouse preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Teclado', 'Teclado sem fio da Microsoft', 195.85, 'Teclado preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Caixa de som JBL', 'Caixa de som JBL', 355.85, 'Caixa de som bluetoof', 1);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Game of Thrones', 'Livro original da série', 200, 'Volume 1', 2);

INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Mouse', 'Mouse sem fio da Microsoft', 95.85, 'Mouse preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Teclado', 'Teclado sem fio da Microsoft', 195.85, 'Teclado preto bluetoof', 3);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Caixa de som JBL', 'Caixa de som JBL', 355.85, 'Caixa de som bluetoof', 1);
INSERT INTO tb_produto(nome, descricao, preco, caracteristica, categoria_id) VALUES('Game of Thrones', 'Livro original da série', 200, 'Volume 1', 2);

